﻿namespace TeisterMask.DataProcessor
{
    using System;
    using System.Linq;
    using Data;
    using Newtonsoft.Json;
    using Formatting = Newtonsoft.Json.Formatting;

    public class Serializer
    {
        public static string ExportProjectWithTheirTasks(TeisterMaskContext context)
        {
            return "";
        }

        public static string ExportMostBusiestEmployees(TeisterMaskContext context, DateTime date)
        {
            var employees = context.Employees.Where(e => e.EmployeesTasks.Any(et => et.Task.OpenDate >= date))
                .ToArray()
                .Select(e => new
                {
                    Username = e.Username,
                    Tasks = e.EmployeesTasks.Select(et => new
                    {
                        TaskName = et.Task.Name,
                        OpenDate = et.Task.OpenDate.ToString("d"),
                        DueDate = et.Task.DueDate.ToString("d"),
                        LabelType = et.Task.LabelType.ToString(),
                        ExecutionType = et.Task.ExecutionType.ToString()
                    }).OrderByDescending(t => t.DueDate).ThenBy(t => t.TaskName).ToArray()
                }).ToArray().OrderByDescending(e => e.Tasks.Count()).ThenBy(e => e.Username);

            string json = JsonConvert.SerializeObject(employees, Formatting.Indented);
            return json;
        }
    }
}