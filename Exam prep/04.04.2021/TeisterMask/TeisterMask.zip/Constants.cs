﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeisterMask
{
    public class Constants
    {
        public const int USERNAME_MAX_LENGTH = 40;
        public const int PHONENUMBER_MAX_LENGTH = 12;
        public const int NAME_MAX_LENGTH = 40;
        public const int NAME_MIN_LENGTH = 2;
    }
}
