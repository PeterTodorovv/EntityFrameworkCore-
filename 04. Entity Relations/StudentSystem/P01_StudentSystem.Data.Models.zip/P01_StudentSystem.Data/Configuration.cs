﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
    public class Configuration
    {
        public const string CONNECTION_STRING = "Server=.;Database=Student System;Trusted_Connection=True;";
    }
}
